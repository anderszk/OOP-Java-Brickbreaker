package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class hiscores extends Application {

    public void makeHSFile() {
        try {
            File myObj = new File("highscores.txt");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void writeHS(String playername, int highscore) throws IOException {
       //Finne en metode å lagre verdiene på. Formattering
       // bw.write(playername+" "+highscore+" \n")
    }

    private void readHS(){
        //leser av hver linje. Må finne en måte å lagre disse verdiene på, forslag:
        //En liste for spiller, en liste for score, tuples med både player og score
        //typ: while(file.readLine() != null) fordi den vil returnere null når den får en blank linje (end of file)
    }

    private void writeToApplication(){
        //legger inn i de ulike elementene typ:
        // this = getElementByID.innerHTML(id) -> this = String(highscore[1])

        //Alternativt: lage nye objekter på skjermen. et objekt for hver plassering 1-10 (ikke tidligere erfaringer)
    }

    private void plotChart(){
        //Pusher data inn i chart for å lagre spillerens ti siste
        //Kan lagres i en ny fil som slettes når brukeren trykker på exit. (vil restarte for hver gang man restarter appen)
        //typ ferdige biblioteker typ chart.js (8-bit theme)
    }

    private void updatePlayerInfo(){
        //Egen boks med antall games spilt,
    }


    @Override
    public void start(Stage stage) throws Exception {
            Parent root = FXMLLoader.load(getClass().getResource("hiscores.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("TDT4100 - HIGHSCORES! - Anders og Elvira");
            stage.show();
    }

}
