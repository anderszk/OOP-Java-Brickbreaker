package sample;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class controllerMainMenu {

    @FXML
    private AnchorPane rootPane;

    @FXML
    public void toMainMenu(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("TDT4100 - Scuffed Breakout - Anders og Elvira");
        stage.show();
    }

    @FXML
    public void toGame(ActionEvent e){
        //Redirect to game
        System.out.println("To game");
    }

    @FXML
    private void toHiscores(ActionEvent e) throws IOException {
        System.out.println("To highscores");
        try {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("hiscores.fxml"));
            rootPane.getChildren().setAll(pane);
        }
        catch(Exception lol){
            System.out.println(lol);
        }
    }

    @FXML
    public void quitApplication(ActionEvent e){
        Platform.exit();
        System.out.println("Quit application");
    }

}
