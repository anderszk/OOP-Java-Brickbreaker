package sample.breakoutGame;

import javafx.scene.shape.Circle;

public class gameBall extends Circle {
}
