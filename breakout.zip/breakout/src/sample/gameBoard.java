package sample;

import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import sample.breakoutGame.gamePaddle;

public class gameBoard{

    //Må detektere når brukeren trykker på quit eller krysser ut, litt usikker på hvordan man dettekterer den siste.
    private int sessionCount = 50;
    private long currentBest = 265389;
    private long score;

    public int getSessionCount(){
        return this.sessionCount;
    }
    public long getCurrentBest(){
        return this.currentBest;
    }

    public void updateScore(Text score, long points){
        this.score += points;
        if (this.score > 999999){
            this.score = 999999;
            score.setText(String.valueOf(this.score));
        }
        else {
            score.setText(String.valueOf(this.score));
        }
    }
    public long getScore(){
        return this.score;
    }

    protected void createPaddle(AnchorPane pane, gamePaddle pad){
        pane.getChildren().add(pad);
    }

}
