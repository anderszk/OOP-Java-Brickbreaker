package sample;


import javafx.animation.AnimationTimer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import sample.breakoutGame.gamePaddle;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class controllerGameBoard implements Initializable {

    private final gamePaddle paddle = new gamePaddle(325, 500, 150, 25, Color.RED);
    private gameBoard gb = new gameBoard();
    private Hiscores hs = new Hiscores();

    @FXML
    AnchorPane gamePane;
    @FXML
    Text score;


    public  AnimationTimer timer = new AnimationTimer() {
        double speed;
        @Override
        public void handle(long now) {
            Scene gameScene = gamePane.getScene();
            gameScene.setOnKeyPressed(f -> {
                if(f.getCode() == KeyCode.A ^ f.getCode() == KeyCode.D){
                    switch (f.getCode()) {
                        case A -> speed = -7;
                        case D -> speed = 7;
                    }
                }
            });
            paddle.setTranslateX(paddle.getTranslateX()+speed);
        }
    };


    @FXML
    private void toMainMenu(ActionEvent e) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("sample.fxml"));
        gamePane.getChildren().setAll(pane);
    }


    @FXML
    public void move(KeyEvent event) throws InterruptedException { ;
        timer.start();
    }
    @FXML
    public void stop(KeyEvent event) throws InterruptedException { ;
        timer.stop();
    }



    @Override

    public void initialize(URL url, ResourceBundle resourceBundle) {
        gb.createPaddle(gamePane, paddle);
        gb.createBricks(gamePane);
        paddle.getStyleClass().add("paddle");
        paddle.setArcHeight(40.0);
        paddle.setArcWidth(26.0);
    }
}
