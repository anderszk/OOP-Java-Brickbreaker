package sample;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import sample.breakoutGame.gamePaddle;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class controllerGameBoard implements Initializable {

    private final gamePaddle paddle = new gamePaddle(325, 500, 150, 25, Color.RED);
    private gameBoard gb = new gameBoard();
    private Hiscores hs = new Hiscores();

    @FXML
    AnchorPane gamePane;
    @FXML
    Text score;



    @FXML
    private void toMainMenu(ActionEvent e) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("sample.fxml"));
        gamePane.getChildren().setAll(pane);
    }



    @FXML
    public void move(KeyEvent event) {
        Scene gameScene = gamePane.getScene();
        gameScene.setOnKeyPressed(f -> {
            switch (f.getCode()) {
                case A -> this.paddle.movePaddleLeft();
                case D -> this.paddle.movePaddleRight();
                case P -> gb.updateScore(this.score, 10500); //Må slettes, er kun for test. Kjøres hver gang den treffer en brick.
                case O -> {
                    try {
                        this.hs.writePlayerInfo(gb.getScore(), 12); //Error, må finne ny ledig linje
                        this.hs.writeHS("hei", "123123");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }



    @Override

    public void initialize(URL url, ResourceBundle resourceBundle) {
        gb.createPaddle(gamePane, paddle);
        paddle.getStyleClass().add("paddle");
        paddle.setArcHeight(40.0);
        paddle.setArcWidth(26.0);
    }
}
