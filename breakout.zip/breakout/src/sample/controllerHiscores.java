package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class controllerHiscores {

    @FXML
    private AnchorPane hiscorePane;

    @FXML
    private void toMainMenu(ActionEvent e) throws IOException {
        System.out.println("To highscores");
        try {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("sample.fxml"));
            hiscorePane.getChildren().setAll(pane);
        }
        catch(Exception lol){
            System.out.println(lol);
        }
    }
}
