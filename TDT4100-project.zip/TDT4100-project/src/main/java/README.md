# Prosjekt i TDT4100 - Objektorientert programmering 
En versjon av Atari Breakout som ble laget i sammenheng med et skoleprosjekt i emnet TDT4100 - Objektorientert programmingering. <br>


*Laget av:
Aalerud, Elvira
Kristensen, Anders

filbehandling:
https://www.youtube.com/watch?v=8gMd0ftWp_Y&ab_channel=BrandonioProductions

##Innhold

