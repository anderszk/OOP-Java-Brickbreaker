package sample.exceptions;

public class InvalidPlayerCountException extends Exception{
    public InvalidPlayerCountException(String errorMessage) {
        super(errorMessage);
    }

}
