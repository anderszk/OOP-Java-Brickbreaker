package sample;

public class Player {
    private String username;
    private long score;
    private long bestScore;
    private int count;

    /**
     *Creates an instance of a player when entering the name
     *
     * @param username The username of the player
     */
    public Player(String username){
        this.username = username;
    }


    /**
     * Getters and setters
     */

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public long getScore() {
        return this.score;
    }

    public void setScore(long score) {
        this.score = score;
        if (score >= 999999){
            this.score = 999999;
        }
    }

    public long getBestScore(){
    	if (this.getScore()>this.bestScore) {
    		return this.score;
    	}
        return this.bestScore;
    }

    public void setBestScore(long score){
        this.bestScore = score;
    }

    public void incrementPlayCount(){
        this.count++;
    }

    public int getCount(){
        return this.count;
    }
    
    public boolean validateName(String name){
        if (name.isEmpty() != true && name.matches("[A-Za-z0-9]+") && name.length() <= 10){
            return true;
        }
        else{
            return false;
        }
    }
}
