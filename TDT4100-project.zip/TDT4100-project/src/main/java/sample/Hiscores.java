package sample;


import javafx.scene.text.Text;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;

public class Hiscores{

    private WritePlayerInfo writePlayer = new WritePlayerInfo();
    private WriteHighScore writeHS = new WriteHighScore();

    /**
     * Making the storefile for top10 highscores and player, will do nothing if files already exists
     *
     * @throws IOException
     */
    protected void makeFiles() throws IOException {
        File hsFile = new File("storedHighScores.txt");
        File playerFile = new File("storedPlayer.txt");
        if (hsFile.createNewFile()) {
            System.out.println("File created: " + hsFile.getName());
        } else {
            System.out.println("Highscore file already exists.");
        }
        if (playerFile.createNewFile()) {
            System.out.println("File created: " +playerFile.getName());
        } else {
            System.out.println("Player file already exists.");
        }
    }


    /**
     * Updates the selected textelements to show the overall: best highscore, gamecount and gamesessions.
     *
     * @param hiscore The best overall highscore
     * @param gameCount Total games played
     * @param gameSession Total gamesessions
     * @throws FileNotFoundException File does not exists
     */

    protected void updatePlayerInfo(Text hiscore, Text gameCount, Text gameSession) throws FileNotFoundException {

        writePlayer.readFromFile();
        gameSession.setText(String.valueOf(writePlayer.getPlayerHighscore().size()));
        gameCount.setText(String.valueOf(writePlayer.getCount() + new gameBoard().getSessionCount()));
        hiscore.setText(String.valueOf(Collections.max(writePlayer.getPlayerHighscore())));
    }

}
