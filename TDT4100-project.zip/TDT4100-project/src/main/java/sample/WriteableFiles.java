package sample;

import sample.exceptions.InvalidPlayerCountException;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface WriteableFiles {

    /**
     * Function that sends data to the files
     *
     * @param string first thing to be written to the file
     * @param string2 second thing to be written to the file
     * @throws IOException throws an IOException if there is no file to be found
     * @throws InvalidPlayerCountException throws an InvalidPlayerCountException if there is more than 10 names and scores in the highscore-file
     */
    void writeToFile(String string, String string2) throws IOException, InvalidPlayerCountException;

    /**
     * Function that reads data from the file
     *
     * @throws FileNotFoundException
     */
    void readFromFile() throws FileNotFoundException;
}
