package sample;

import sample.exceptions.InvalidPlayerCountException;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class WriteHighScore implements WriteableFiles {

    private final List<String> unsortedhsName = new ArrayList<>(); 
    private final List<Long> unsortedhsScore = new ArrayList<>();
    private final List<String> hsName = new ArrayList<>(); 
    private final List<Long> hsScore = new ArrayList<>();

    /**
     * Writes to the highscore file
     *
     * @param playername The name of the player
     * @param highscore The highscore of the player
     * @throws IOException
     */
    @Override
    public void writeToFile(String playername, String highscore) throws IOException, InvalidPlayerCountException {
    
        
    	readFromFile();
        if(Long.parseLong(highscore) > hsScore.get(9)) {
            List<Long> writeThisScores = new ArrayList<>();
            List<String> writeThisNames = new ArrayList<>();

            this.hsScore.remove(9);
            this.hsScore.add(Long.parseLong(highscore));
            this.hsName.remove(9);
            this.hsName.add(playername);
            if (hsScore.size() == 10 && hsName.size() == 10) {
                FileWriter hs = new FileWriter("storedHighScores.txt");
                hs.flush();
                for (int i = 0; i < 10; i++) {
                    int highest = hsScore.indexOf(Collections.max(hsScore));

                    writeThisScores.add(hsScore.get(highest));
                    writeThisNames.add(hsName.get(highest));

                    hsScore.remove(highest);
                    hsName.remove(highest);

                    hs.write(writeThisNames.get(i) + ":" + writeThisScores.get(i) + "\n");
                }
                hs.close();
            }
            else{
                throw new InvalidPlayerCountException("Playercount not 10, wrong format");
            }
        } else {
            System.out.println("Score not top 10, better luck next time");
        }
    }

    /**
     * Reads from the highscore file and adds to the lists so its retrievable
     *
     * @throws IOException
     */
    @Override
    public void readFromFile() { //Vet ikke hvilken synlighetsmod den skal sa mtp at den blir brukt i main
        try {
            File file = new File("storedHighScores.txt");
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                if (line.isBlank() == true){ 
                    break;
                }
                String[] data = line.split(":");
                System.out.println(data[0]+" "+data[1]);
                unsortedhsName.add(data[0]); //Bruker index for å skille mellom spillere, viktig å lagre index da.
                unsortedhsScore.add(Long.parseLong(data[1]));
                System.out.println("Players: "+unsortedhsName);
                System.out.println("Score: "+unsortedhsScore);
            }
            sortData();
            reader.close();
            System.out.println("file closed");
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        } catch (NoSuchElementException f) {
        	System.out.println("An error occurred.");
        }
  
    }

    public void sortData(){
        for(int k=0; k < 10; k++){
        	System.out.println(unsortedhsScore);
            int highest = unsortedhsScore.indexOf(Collections.max(unsortedhsScore));

            hsScore.add(unsortedhsScore.get(highest));
            hsName.add(unsortedhsName.get(highest));

            unsortedhsScore.remove(highest);
            unsortedhsName.remove(highest);
        }
    }

    /**
     * Getters for the names and scores for the highscores
     *
     * @return Lists with names and scores
     */
    public List<String> getHSNames(){
        System.out.println(hsName);
        return this.hsName;
    }
    public List<Long> getHSScores(){
        return this.hsScore;
    }
}
