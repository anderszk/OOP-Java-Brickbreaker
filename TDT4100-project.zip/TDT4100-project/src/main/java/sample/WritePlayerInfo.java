package sample;

import sample.exceptions.InvalidPlayerCountException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class WritePlayerInfo implements WriteableFiles {


    private final List<Long> personHiscores = new ArrayList<>(); //Inneholder høyeste highscore for hver session.
    private int count;

    /**
     * Write information the the players store-file
     *
     * @param highscore The best highscore for the session
     * @param gamecount How many games the player played from opening the app to closing it
     * @throws IOException
     */
    @Override
    public void writeToFile(String highscore, String gamecount) throws IOException, InvalidPlayerCountException {
        FileWriter pi = new FileWriter("storedPlayer.txt", true);
        pi.write(highscore+":"+gamecount+"\n");
        pi.close();
    }


    /**
     * The read-function
     *
     * @throws FileNotFoundException
     */

    @Override
    public void readFromFile() throws FileNotFoundException {
        int total_score = 0;
        File playerfile = new File("storedPlayer.txt");
        Scanner read = new Scanner(playerfile);
        while (read.hasNextLine()) {
            String line = read.nextLine();
            String[] data = line.split(":");
            total_score = total_score + Integer.parseInt(data[0]);
            this.personHiscores.add(Long.parseLong(data[0])); //Bruker index for å skille mellom spillere, viktig å lagre index da.
            this.count += Integer.parseInt(data[1]);
        }
        System.out.println("The average score of the player is: "+total_score/personHiscores.size());
        read.close();
        personHiscores.add(new gameBoard().getCurrentBest());
    }
    
    
    /**
     *
     * @return List of scores that is going to be added to the GUI
     * @throws FileNotFoundException if file is not found
     */
    protected List<String> scoresToGraph() throws FileNotFoundException {
        List<String> allScores = new ArrayList<>();
        List<String> scoresToBeAdded = new ArrayList<>();

        File playerfile = new File("storedPlayer.txt");
        Scanner read = new Scanner(playerfile);
        while (read.hasNextLine()) {
            String line = read.nextLine();
            String[] data = line.split(":");
            allScores.add(data[0]);
        }
        read.close();

        for(int i=allScores.size()-1; i > allScores.size()-6; i--){
            scoresToBeAdded.add(allScores.get(i));
        }

        Collections.reverse(scoresToBeAdded);


        return scoresToBeAdded;
    }

    /**
     * Getters and setters for data
     */
    public List<Long> getPlayerHighscore(){
        return personHiscores;
    }
    public int getCount(){
        return count;
    }

}
