package sample;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class controllerHiscores implements Initializable {

    @FXML
    private AnchorPane hiscorePane;
    @FXML
    private BarChart last5;
    @FXML
    private NumberAxis y;
    @FXML
    private Text playerHiscore, playerGameCount, playerSessions;

    private final Hiscores hs = new Hiscores();
    private final WriteHighScore writeHS = new WriteHighScore();
    private final WritePlayerInfo writePlayer = new WritePlayerInfo();

    /**
     * Redirects user back to main menu
     *
     * @throws IOException
     */
    @FXML
    private void toMainMenu() throws IOException {
        System.out.println("To main menu");
        AnchorPane pane = FXMLLoader.load(getClass().getResource("fxml/sample.fxml"));
        hiscorePane.getChildren().setAll(pane);
    }

    /**
     * Sets the data to the Text-elements in the .FXML-files
     * @throws FileNotFoundException 
     */
    @FXML
    private void setScores() throws FileNotFoundException{
        writeHS.readFromFile();

        List<String> names = writeHS.getHSNames();
        List<Long> scores = writeHS.getHSScores();

        for (int i =0; i < writeHS.getHSScores().size(); i++) {
            Text name = (Text)(hiscorePane.lookup("#name" + (i+1)));
            Text score = (Text)(hiscorePane.lookup("#score" + (i+1)));
            name.setText(names.get(i));
            score.setText(String.valueOf(scores.get(i)));
        }
    }
    @FXML
    private void setPerson(){
        try {
           hs.updatePlayerInfo(playerHiscore, playerGameCount, playerSessions);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void setGraph() throws FileNotFoundException {

        List<String> lastScores = writePlayer.scoresToGraph();

        XYChart.Series scores = new XYChart.Series();

        for(int i=0; i < lastScores.size(); i++){
            scores.getData().add(new XYChart.Data(String.valueOf(5-i), Long.parseLong(lastScores.get(i))));
        }

        this.last5.getData().add(scores);
        this.last5.setCategoryGap(1);
        this.last5.setBarGap(1);
        this.last5.getXAxis().setOpacity(0);
        this.y.setTickLabelFont(Font.font("Super Legend Boy", 7));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
        	setScores();
            setGraph();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        setPerson();
    }
}
