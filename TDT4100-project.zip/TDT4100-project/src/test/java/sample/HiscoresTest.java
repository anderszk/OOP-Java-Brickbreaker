package sample;

import static org.junit.jupiter.api.Assertions.*;

import sample.exceptions.InvalidPlayerCountException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import javafx.scene.text.Text;


class HiscoresTest {
	
	//private final List<String> unsortedhsName = Arrays.asList("a", "i", "b", "e", "c", "d", "j", "h", "g", "f");
	//private final List<Long> unsortedhsScore = Arrays.asList((long) 20000, (long) 30000, (long) 10000, (long) 50000, (long) 100000, (long) 40000, (long) 90000, (long) 70000, (long) 80000, (long) 60000);
	private final List<String> unsortedhsName = new ArrayList<>();
	private final List<Long> unsortedhsScore = new ArrayList<>();
	private final List<String> hsName = new ArrayList<>();
	private final List<Long> hsScore = new ArrayList<>();
	private final List<Long> personHiscores = new ArrayList<>();
	
	private Hiscores hs;
	private String player;
    private WritePlayerInfo writePlayer = new WritePlayerInfo();
    private WriteHighScore writeHS = new WriteHighScore();
	private long score;
	private long hiscore;
	private long count;
	

	@BeforeEach
	void setup() {
		this.hs = new Hiscores();
		this.player = "Elvira";
		this.score = 90000;
		this.hiscore = 999999;
		this.count = 0;
	}
	
	@Test
	@DisplayName("Testing the 'makeFile()' method in Hiscores.java.")
	void testMakeFiles() {
		File oldPlayerFile = new File("storedPlayer.txt");
		File newPlayerFile = new File("storedPlayer.txt");
		File oldHsFile = new File("storedHighScores.txt");
		File newHsFile = new File("storedHighScores.txt");
		if (oldPlayerFile.exists() && oldHsFile.exists()) {
			try {
				hs.makeFiles();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Something went wrong when testing in Hiscores.makeFiles().");
			}
		}
		
		assertTrue(new File("storedPlayer.txt").exists());
		assertTrue(new File("storedHighScores.txt").exists());
		assertTrue(oldPlayerFile.getName().equals(newPlayerFile.getName()));
		assertTrue(oldHsFile.getName().equals(newHsFile.getName()));
		assertEquals(0, oldPlayerFile.compareTo(newPlayerFile));
		assertEquals(0, oldHsFile.compareTo(newHsFile));
	}
}
