package sample;

import javafx.scene.text.Text;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class gameBoardTest {

    gameBoard gb = new gameBoard();
    Text text = new Text();

    @BeforeEach
    void setUp() {
        gb = new gameBoard();
    }

    @Test
    void scoreTest() {
        gb.updateScore(text, 50000);
        assertEquals(50000, gb.getScore());
        assertNotEquals(0, gb.getScore());

        gb.updateScore(text,990000);
        assertEquals(999999, gb.getScore());
        assertNotEquals(1140000, gb.getScore());

        gb.updateScore(text,50000);
        assertEquals(999999, gb.getScore());
        assertNotEquals(1640000, gb.getScore());
    }
}