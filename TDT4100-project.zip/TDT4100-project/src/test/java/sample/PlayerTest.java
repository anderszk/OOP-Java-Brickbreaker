package sample;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlayerTest {

    Player elvira = new Player("Elvira");
    String name = "Elvira";

    private long score;
    private long bestScore;
    private int count;

    @BeforeEach
    void setUp() {
        elvira = new Player("Elvira");
        elvira.setScore(100000);
        elvira.setBestScore(0);
    }
    
    @Test
    void testUsername() {
        elvira.setUsername("Anders");
        assertEquals("Anders", elvira.getUsername());
        assertNotEquals("Elvira", elvira.getUsername());
        assertTrue(elvira.validateName("Anders"));
        assertFalse(elvira.validateName("ElviraAalerud"));
    }

    @Test
    void testScore() {
        assertEquals(100000, elvira.getScore());
        assertNotEquals(120000, elvira.getScore());

        assertEquals(100000, elvira.getScore());
        elvira.setScore(400000);
        assertEquals(400000, elvira.getScore());
        assertNotEquals(100000, elvira.getScore());
    }



    @Test
    void testBestScore() {
        assertEquals(0, elvira.getBestScore());
        assertNotEquals(100000, elvira.getBestScore());

        elvira.setBestScore(999999);
        assertEquals(999999, elvira.getBestScore());
        assertNotEquals(0, elvira.getBestScore());
    }




    @Test
    void getCount() {
        assertEquals(0, elvira.getCount());
        for(int i = 0; i < 3; i++){
            elvira.incrementPlayCount();
        }
        assertEquals(3, elvira.getCount());
    }
}