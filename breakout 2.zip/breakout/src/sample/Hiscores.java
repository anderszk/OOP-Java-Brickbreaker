package sample;


import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Hiscores extends MainMenu{

    private FileReader file = null;
    private BufferedReader hsFile = null;
    protected List<String> hsName = new ArrayList<>(); //String-objekter eller highscore-objekter?
    protected List<Long> hsScore = new ArrayList<Long>();


    public void makeHSFile() throws IOException {
        File hsFile = new File("storedHighScores.txt");
        if (hsFile.createNewFile()) {
            System.out.println("File created: " + hsFile.getName());
        } else {
            System.out.println("File already exists.");
        }
    }

    public void writeHS(String playername, String highscore) throws IOException {
        //Er nødt til å stringifye highscoren.
        FileWriter hs = new FileWriter("highscores.txt");
        hs.write(playername+":"+highscore+"\n");
        System.out.println("Wrote to system: "+playername+", "+highscore);
    }

    protected void readHS() throws IOException { //Vet ikke hvilken synlighetsmod den skal sa mtp at den blir brukt i main
        try {
            File file = new File("storedHighScores.txt");
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                String[] data = line.split(":");
                hsName.add(data[0]); //Bruker index for å skille mellom spillere, viktig å lagre index da.
                hsScore.add(Long.parseLong(data[1]));
                System.out.println("Players: "+hsName);
                System.out.println("Score: "+hsScore);
            }
            reader.close();
            System.out.println("file closed");
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public List<String> getHSNames(){
        System.out.println(hsName);
        return this.hsName;
    }

    public List<Long> getHSScores(){
        return this.hsScore;
    }





    private void plotChart(){
        //Pusher data inn i chart for å lagre spillerens ti siste
        //Kan lagres i en ny fil som slettes når brukeren trykker på exit. (vil restarte for hver gang man restarter appen)
        //typ ferdige biblioteker typ chart.js (8-bit theme)
    }

    private void updatePlayerInfo(){
        //Egen boks med antall games spilt,
    }

    //Testfunksjoner
}
