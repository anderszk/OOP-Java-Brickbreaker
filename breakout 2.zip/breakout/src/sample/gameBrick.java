package sample;

import javafx.scene.shape.Rectangle;

public class gameBrick extends Rectangle {
}
