package sample;

import java.awt.*;

import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.paint.Color;

public class gamePaddle extends Rectangle{
    int height;

    public gamePaddle(int x, int y, int w, int h, Color color){
        super(w, h, color);
        setTranslateX(x);
        setTranslateY(y);
    }


    void movePaddleRight(){
        setTranslateX(getTranslateX() + 20);
    }

    void movePaddleLeft(){
        setTranslateX(getTranslateX() - 20);
    }



}
