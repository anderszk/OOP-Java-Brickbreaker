package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class controllerHiscores implements Initializable {

    private Hiscores hs = new Hiscores();

    @FXML
    private AnchorPane hiscorePane;
    @FXML
    private Text name1,name2,name3,name4,name5,name6,name7,name8,name9,name10;
    @FXML
    private Text score1,score2,score3,score4,score5,score6,score7,score8,score9,score10;

    public controllerHiscores() {
    }


    @FXML
    private void toMainMenu(ActionEvent e) throws IOException {
        System.out.println("To main menu");
        AnchorPane pane = FXMLLoader.load(getClass().getResource("sample.fxml"));
        hiscorePane.getChildren().setAll(pane);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Hiscores hs = new Hiscores();
        try {
            hs.readHS();
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<String> names = hs.getHSNames();
        List<Long> scores = hs.getHSScores();
        name1.setText(names.get(0));
        name2.setText(names.get(1));
        name3.setText(names.get(2));
        name4.setText(names.get(3));
        name5.setText(names.get(4));
        name6.setText(names.get(5));
        name7.setText(names.get(6));
        name8.setText(names.get(7));
        name9.setText(names.get(8));
        name10.setText(names.get(9));


        score1.setText(String.valueOf(scores.get(0)));
        score2.setText(String.valueOf(scores.get(1)));
        score3.setText(String.valueOf(scores.get(2)));
        score4.setText(String.valueOf(scores.get(3)));
        score5.setText(String.valueOf(scores.get(4)));
        score6.setText(String.valueOf(scores.get(5)));
        score7.setText(String.valueOf(scores.get(6)));
        score8.setText(String.valueOf(scores.get(7)));
        score9.setText(String.valueOf(scores.get(8)));
        score10.setText(String.valueOf(scores.get(9)));

    }
}
