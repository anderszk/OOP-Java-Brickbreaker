package sample;

import java.awt.*;
import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;

public class gameBoard extends MainMenu{



    protected void createPaddle(AnchorPane pane, gamePaddle pad){
        pane.getChildren().add(pad);
        System.out.println("added");
    }

}
